---
name: zachman-architecture-docs
description: "Document a system, project, or organization's architecture using the Zachman Framework taxonomy (6 rows x 6 columns). Use when documenting architecture via Zachman, mapping artifacts onto the matrix, or auditing which cells are covered."
---

# Zachman Architecture Documentation

## Purpose

Help the user build and maintain architecture documentation for a specific system or project, organized according to the Zachman Framework: a 6x6 taxonomy of rows (perspectives) x columns (interrogatives). This skill does NOT invent architecture — it elicits, extracts, and organizes what the user (or their existing materials) already knows, and clearly flags what's still missing. Zachman is a taxonomy, not a methodology: it classifies artifacts, it doesn't prescribe a process for producing them.

## The taxonomy (reference)

Rows (perspectives, general → specific):
1. Contextual (Scope / Planner) — the enterprise/system boundary as the executive sees it
2. Conceptual (Business Model / Owner) — business concepts and relationships, technology-agnostic
3. Logical (System Model / Designer) — logical models independent of specific technology
4. Physical (Technology Model / Builder) — concrete technology choices and implementation constraints
5. Detailed (Component / Subcontractor) — out-of-context component specs (code, configs, schemas)
6. Functioning (Operational instance / User) — the system as it actually runs

Columns (interrogatives):
- What (Data) — things/entities
- How (Function) — processes/activities
- Where (Network) — locations/topology
- Who (People) — roles/organization
- When (Time) — events/cycles
- Why (Motivation) — goals/strategy/rules

Each cell is an independent, self-sufficient model of that row x column combination — it is NOT a decomposition or elaboration of the cell above it. Treat rows as different perspectives on the same system, not a waterfall hierarchy.

## Workflow

1. **Scope first.** Before touching the matrix, establish: what system/project is being documented, and — critically — which rows and columns actually matter right now. Filling all 36 cells is rarely useful or realistic; most real documentation efforts focus on 2-3 adjacent rows (commonly Conceptual→Physical) and whichever columns the audience cares about (often What/How/Why for business-facing docs, How/Where/Who for ops-facing docs). Ask the user to scope it if they haven't — never default to "all 36 cells" without confirming.

2. **Reuse before asking.** Before interactively eliciting a cell, check whether the user has already provided material that answers it — uploaded docs, code, config files, prior project context, memory of past conversations. Extract from those first, note the provenance, and only ask the user directly for what's genuinely missing or ambiguous. Don't re-ask for something already stated or documented elsewhere. On a greenfield system with nothing to reuse, say so briefly and move straight to elicitation.

3. **Elicit by row, not by isolated cell.** Default cluster size is one full row (all in-scope columns) per message — a short, concrete question per column, e.g. "What: key entities? How: main process steps? Where: locations? Who: roles? Why: business goal? When: key time cycles/deadlines?". A full row is usually a coherent, quick-to-answer unit and keeps the pace practical. Drop to a smaller cluster (2-3 columns, or a single cell) only when a row turns out to need real back-and-forth — conflicting answers, a column the user is unsure about, or a domain that's genuinely complex. Accept partial answers or "not applicable" — not every cell needs content for every system, and forcing content into an inapplicable cell defeats the purpose.

4. **Persist as a living document**, not a one-off file — this is documentation the user will return to and revise over time. Use the Claude Docs tooling (load its skill first) unless the user explicitly asks for a different format (e.g. a plain file for version control). Structure the document as:
   - A summary table up top: rows x columns grid showing status per cell (Filled / Draft / N/A / Not started)
   - One section per in-scope row, with subsections per in-scope column, each holding the actual content plus a one-line provenance note (stated by user / extracted from <source> / inferred — flag inferred content explicitly for the user to confirm)

5. **Flag cross-row inconsistencies as a distinct callout, not a buried note.** As lower rows (Logical, Physical, Detailed, Functioning) get filled in, their answers will sometimes narrow, contradict, or outgrow what an earlier, already-Filled higher row said (e.g. Logical planned three ordering channels, but Physical reveals only one is actually implemented; or a Conceptual role turns out to not exist at the Physical level). This is not an error to quietly reconcile — it's exactly the kind of gap the framework exists to surface. When it happens: keep both cells' content as stated (don't retroactively rewrite the earlier row to match); give the discrepancy its own clearly labeled callout near the newer cell (e.g. a "Discrepancy" or "⚠" block), not folded into the ordinary one-line provenance note used for everything else; and say it plainly in the chat reply too — never leave it only inside the document for the user to stumble on.

6. **Resuming work.** When invoked again for a project that already has a Zachman doc, read it first, show the user the current completeness table, and continue from the highest-value gaps rather than starting over. Never silently regenerate or overwrite a cell already marked Filled — ask first if the user wants it revised.

7. **Stay honest about gaps.** Don't paper over an empty cell with generic boilerplate or filler. An empty or genuinely-not-applicable cell should say so plainly in the summary table — the whole value of using this framework is seeing where documentation is actually thin, not producing the appearance of completeness.

8. **Exporting or translating the finished doc.** When the user asks for the matrix in another format (PDF, DOCX, another language), build that deliverable directly from the content this skill already authored in the doc — you wrote it, so reuse it rather than round-tripping it through a fragile extraction step (e.g. don't manually pipe a large base64/markdown export through a shell heredoc; either use the docs export tool's output directly as a file, or, for a same-session doc, reconstruct from the content you already have in context). The goal is a deliverable that matches the doc exactly, produced the shortest reliable way.

## Output language

Match the user's own working language in the actual document content — the taxonomy row/column labels above are reference terms for Claude's own orientation, not text that must appear verbatim in the output.